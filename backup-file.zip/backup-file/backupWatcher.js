const fs = require('fs'); 
const path = require('path');  


const sourceFilePath = 'path/to/your/source/file.txt';


const backupFolderPath = 'C:\New folder\Node JS folder';

if (!fs.existsSync(backupFolderPath)) {
    fs.mkdirSync(backupFolderPath, { recursive: true });
    console.log('Backup folder created successfully.');
} else {
    console.log('Backup folder already exists.');
}


const createBackup = () => {
    try {
        const fileName = path.basename(sourceFilePath);  
        const backupFilePath = path.join(backupFolderPath, `${Date.now()}_${fileName}`);  
        fs.copyFileSync(sourceFilePath, backupFilePath); 
        console.log(`Backup created at ${backupFilePath}`);  
    } catch (err) {
        if (err.code === 'ENOENT') {  
            console.error('File not found. Please check the source file path.');
        } else {  
            console.error(`Error creating backup: ${err.message}`);
        }
    }
};


fs.watch(sourceFilePath, (eventType) => {
    if (eventType === 'change') {  
        console.log('File change detected. Creating backup...');
        createBackup();  
    }
});

console.log('Watching for file changes...');
