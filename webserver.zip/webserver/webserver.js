const express = require('express');
const path = require('path');
const app = express();
const port = 3000;


app.use(express.urlencoded({ extended: true }));


app.get('/form', (req, res) => {
  res.sendFile(path.join(__dirname, 'form.html'));
});


app.post('/form', (req, res) => {
  console.log('Form Data:', req.body);
  res.send('Form submitted successfully!');
});

app.listen(port, () => {
  console.log(`Server is running at http://localhost:${port}/form`);
});
