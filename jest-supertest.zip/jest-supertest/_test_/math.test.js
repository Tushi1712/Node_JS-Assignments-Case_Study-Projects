// math.test.js
const { sum } = require('./math');

describe('Math Module - Sum Function', () => {
  test('should return the sum of numbers in an array', () => {
    const numbers = [1, 2, 3, 4];
    expect(sum(numbers)).toBe(10);
  });

  test('should return 0 for an empty array', () => {
    expect(sum([])).toBe(0);
  });

  test('should handle negative numbers', () => {
    expect(sum([-1, -2, -3])).toBe(-6);
  });
});