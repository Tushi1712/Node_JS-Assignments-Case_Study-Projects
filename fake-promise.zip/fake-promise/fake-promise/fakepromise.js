function fakePromise(duration, data) {
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve(JSON.stringify(data));
        }, duration);
    });
}

// Usage example
const duration = 2000; // 2 seconds
const data = { message: "Hello, world!" };

fakePromise(duration, data).then((result) => {
    console.log(result); // Output: {"message":"Hello, world!"}
});
