// Middleware to parse JSON data
app.use(bodyParser.json());

// Connect to MongoDB
mongoose.connect("mongodb://127.0.0.1:27017/todoDB", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

// Verify MongoDB connection
const db = mongoose.connection;
db.on("error", console.error.bind(console, "MongoDB connection error:"));
db.once("open", () => {
  console.log("Connected to MongoDB");
});

// Define your Todo model
const todoSchema = new mongoose.Schema({
  description: { type: String, required: true },
  done: { type: Boolean, default: false },
});
const Todo = mongoose.model("Todo", todoSchema);

// Add your routes here
// GET - /todos (Get all todos)
app.get("/todos", async (req, res) => {
  try {
    const todos = await Todo.find();
    res.json(todos);
  } catch (error) {
    res.status(500).send(error.message);
  }
});

// POST - /todos (Save a todo)
app.post("/todos", async (req, res) => {
  try {
    const newTodo = new Todo({
      description: req.body.description,
      done: req.body.done,
    });
    const savedTodo = await newTodo.save();
    res.status(201).json(savedTodo);
  } catch (error) {
    res.status(500).send(error.message);
  }
});

// GET - /todos/:id (Get a todo with given id)
app.get("/todos/:id", async (req, res) => {
  try {
    const todo = await Todo.findById(req.params.id);
    if (!todo) {
      return res.status(404).send("Todo not found");
    }
    res.json(todo);
  } catch (error) {
    res.status(500).send(error.message);
  }
});

// PUT|POST - /todos/:id (Update a todo with given id)
app.put("/todos/:id", async (req, res) => {
  try {
    const updatedTodo = await Todo.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );
    if (!updatedTodo) {
      return res.status(404).send("Todo not found");
    }
    res.json(updatedTodo);
  } catch (error) {
    res.status(500).send(error.message);
  }
});

// DELETE - /todos/:id (Delete a todo with given id)
app.delete("/todos/:id", async (req, res) => {
  try {
    const deletedTodo = await Todo.findByIdAndDelete(req.params.id);
    if (!deletedTodo) {
      return res.status(404).send("Todo not found");
    }
    res.json(deletedTodo);
  } catch (error) {
    res.status(500).send(error.message);
  }
});

// Start your server
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});