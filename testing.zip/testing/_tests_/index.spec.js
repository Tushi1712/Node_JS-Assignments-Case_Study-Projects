// _tests_/index.spec.js
const makeGreeter = require('../index');

describe('Greeting Module', () => {
    it ('Greets Correctly', () => {
        const greeter = makeGreeter('Hello');
        expect(greeter('Jane')).toEqual('Hello, Jane')
    })
});

