// index.js
function makeGreeter(greeting) {
    return function(name) {
        return `${greeting}, ${name}`;
    };
}

module.exports = makeGreeter;