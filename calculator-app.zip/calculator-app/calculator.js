const readline = require('readline');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

function showMenu() {
  console.log(`
  Select an operation:
  1. Addition
  2. Subtraction
  3. Multiplication
  4. Division
  5. Exit
  `);

  rl.question('Enter your choice (1-5): ', (choice) => {
    if (choice === '5') {
      console.log('Exiting the application.');
      rl.close();
    } else {
      rl.question('Enter the first number: ', (num1) => {
        rl.question('Enter the second number: ', (num2) => {
          const a = parseFloat(num1);
          const b = parseFloat(num2);

          switch (choice) {
            case '1':
              console.log(`Result: ${a} + ${b} = ${a + b}`);
              break;
            case '2':
              console.log(`Result: ${a} - ${b} = ${a - b}`);
              break;
            case '3':
              console.log(`Result: ${a} * ${b} = ${a * b}`);
              break;
            case '4':
              if (b === 0) {
                console.log('Error: Division by zero is not allowed.');
              } else {
                console.log(`Result: ${a} / ${b} = ${a / b}`);
              }
              break;
            default:
              console.log('Invalid choice. Please try again.');
          }
          showMenu();
        });
      });
    }
  });
}

showMenu();
