console.log('App2 is starting...');

const express = require('express');
const mongoose = require('mongoose');
const app = express();

app.use(express.json());

// MongoDB connection
mongoose.connect('mongodb://127.0.0.1:27017/todosDB', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
}).then(() => console.log('Connected to MongoDB'))
  .catch(err => console.error('MongoDB connection error:', err));

// Define the Todo schema and model
const todoSchema = new mongoose.Schema({
    title: { type: String, required: true },
    description: { type: String, required: true },
    completed: { type: Boolean, required: true },
});

const Todo = mongoose.model('Todo', todoSchema);

// REST API endpoints
app.post('/todos', async (req, res) => {
    try {
        const { title, description, completed } = req.body;

        // Validate request body
        if (!title || !description || typeof completed !== 'boolean') {
            return res.status(400).send({ message: 'Invalid input. Ensure title, description, and completed are provided.' });
        }

        const todo = new Todo({ title, description, completed });
        const savedTodo = await todo.save();
        res.status(201).send(savedTodo);
    } catch (error) {
        res.status(500).send({ message: 'Error saving todo', error: error.message });
    }
});

app.get('/todos', async (req, res) => {
    try {
        const todos = await Todo.find();
        res.status(200).send(todos);
    } catch (error) {
        res.status(500).send({ message: 'Error retrieving todos', error: error.message });
    }
});

const PORT = 4000;
app.listen(PORT, () => {
    console.log(`App2 is running on http://localhost:${PORT}`);
});