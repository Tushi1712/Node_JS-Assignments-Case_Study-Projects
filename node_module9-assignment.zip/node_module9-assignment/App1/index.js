console.log('App1 is starting...');

const express = require('express');
const axios = require('axios');
const app = express();

app.use(express.json());

// Forward requests to the second application
app.post('/todos', async (req, res) => {
    try {
        const response = await axios.post('http://localhost:4000/todos', req.body, { timeout: 5000 });
        res.status(response.status).send(response.data);
    } catch (error) {
        if (error.code === 'ECONNABORTED') {
            res.status(504).send({ message: 'Request to App2 timed out' });
        } else if (error.response) {
            res.status(error.response.status).send({ message: 'Error from App2', error: error.response.data });
        } else {
            res.status(500).send({ message: 'Error passing request to App2', error: error.message });
        }
    }
});

app.get('/todos', async (req, res) => {
    try {
        const response = await axios.get('http://localhost:4000/todos', { timeout: 5000 });
        res.status(response.status).send(response.data);
    } catch (error) {
        if (error.code === 'ECONNABORTED') {
            res.status(504).send({ message: 'Request to App2 timed out' });
        } else if (error.response) {
            res.status(error.response.status).send({ message: 'Error from App2', error: error.response.data });
        } else {
            res.status(500).send({ message: 'Error fetching todos from App2', error: error.message });
        }
    }
});

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`App1 is running on http://localhost:${PORT}`);
});