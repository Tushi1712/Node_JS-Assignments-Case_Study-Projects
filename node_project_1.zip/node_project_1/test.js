console.log('Hello, World!');
// Output: Hello, World!