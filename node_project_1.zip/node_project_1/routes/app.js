const express = require('express');
const app = express();
const path = require('path');
const bodyParser = require('body-parser');
const session = require('express-session');
const flash = require('connect-flash');

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.urlencoded({ extended: false }));

app.use(session({
    secret: 'your-secret-key',
    resave: false,
    saveUninitialized: true
}));

app.use(flash());

app.get('/profile', (req, res) => {
  const user = req.session.user = { name: 'John Doe', email: 'john.doe@example.com' }; // Assuming user data is stored in the session
  if (!user) return res.redirect('/login'); // Redirect to login if not authenticated
  res.render('profile', { user }); // Render profile.ejs with user data
});

// Example: Home Route
app.get('/', (req, res) => {
    res.render('index');
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));

const mongoose = require('mongoose');

// Replace 'yourdbname' with the name of your database
//mongoose.connect('mongodb://localhost:27017/yourDatabaseName');

// Connecting to MongoDB
const dbURI = 'mongodb://localhost:27017/';
mongoose.connect('mongodb://localhost:27017/node_project_1', {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
.then(() => console.log('MongoDB connection successful'))
.catch((err) => console.error('MongoDB connection error:', err));