git clone <repository-url>
cd <repository-folder>

npm install

npm start

The server will start on http://localhost:5000

POST/posts
response: JSON
{
  "title": "Blog Post Title",
  "content": "Content of the blog post",
  "author": "Author Name"
}

GET/posts
response: JSON
[
  {
    "id": "1",
    "title": "Sample Title",
    "content": "Sample Content",
    "author": "Author Name",
    "createdAt": "2023-10-01T00:00:00.000Z"
  },
  ...
]

GET/posts/:id
response: JSON
{
  "id": "1",
  "title": "Sample Title",
  "content": "Sample Content",
  "author": "Author Name",
  "createdAt": "2023-10-01T00:00:00.000Z"
}

PUT/posts/:id
response: JSON
{
  "title": "Updated Title",
  "content": "Updated Content"
}

DELETE/posts/:id
response: JSON
{
  "message": "Blog post deleted successfully"
}

Use Postman or any other API testing tool to test the endpoints:

project-folder/
├── models/
│   └── BlogPost.js          # Mongoose schema for blog posts
├── routes/
│   └── postRoutes.js        # API routes
├── controllers/
│   └── postController.js    # Handles request logic
├── app.js                   # Main application file
├── package.json             # Project metadata and dependencies
└── README.md                # Project documentation
