const greet = name => 'Hello, ${name}'
module.exports = {greet};