'use strict';

/** @type {import('./pow')} */
module.exports = Math.pow;
