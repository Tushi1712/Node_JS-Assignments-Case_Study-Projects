import express from 'express';
const app = express();
import { greet } from './services/greeting-service';

app.get('/greeting', (req, res) => {
    const name = req.query['name'];
    res.status(200).send(greet(name));
});

app.listen(8000, () => console.log("Server is running on port 8000"));
