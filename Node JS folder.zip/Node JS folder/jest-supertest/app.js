// app.js
const express = require('express');
const { sum } = require('./math');

const app = express();

// Middleware to parse JSON request bodies
app.use(express.json());

// POST endpoint at /sum which expects an array of numbers in req.body.numbers
app.post('/sum', (req, res) => {
  const { numbers } = req.body;

  // Validate that numbers exists and is an array
  if (!Array.isArray(numbers)) {
    return res.status(400).json({ error: 'Invalid data: "numbers" must be an array.' });
  }

  // Compute the sum using our math module
  const result = sum(numbers);
  res.status(200).json({ sum: result });
});

module.exports = app;