// app.test.js
const request = require('supertest');
const app = require('./app');

describe('Integration Tests for /sum API', () => {
  test('POST /sum returns correct sum for valid numbers array', async () => {
    const response = await request(app)
      .post('/sum')
      .send({ numbers: [10, 20, 30] })
      .set('Content-Type', 'application/json');

    expect(response.statusCode).toBe(200);
    expect(response.body).toEqual({ sum: 60 });
  });

  test('POST /sum returns 400 error for invalid data type', async () => {
    const response = await request(app)
      .post('/sum')
      .send({ numbers: "not an array" })  // invalid input
      .set('Content-Type', 'application/json');

    expect(response.statusCode).toBe(400);
    expect(response.body.error).toMatch(/Invalid data/);
  });

  test('POST /sum with empty array should return 0', async () => {
    const response = await request(app)
      .post('/sum')
      .send({ numbers: [] })
      .set('Content-Type', 'application/json');

    expect(response.statusCode).toBe(200);
    expect(response.body).toEqual({ sum: 0 });
  });
});