// math.js
function sum(numbers) {
    // Using reduce to sum the array values, starting at 0.
    // This will work even if the array is empty.
    return numbers.reduce((accumulator, current) => accumulator + current, 0);
  }
  
  module.exports = { sum };