const express = require('express');
const bodyParser = require('body-parser');
const axios = require('axios');

const app = express();
app.use(bodyParser.json());

// Route to save a todo
app.post('/todos', async (req, res) => {
    try {
        const response = await axios.post('http://localhost:5000/todos', req.body);
        res.status(response.status).send(response.data);
    } catch (error) {
        res.status(500).send({ error: 'Failed to save todo' });
    }
});

// Route to fetch all todos
app.get('/todos', async (req, res) => {
    try {
        const response = await axios.get('http://localhost:5000/todos');
        res.status(response.status).send(response.data);
    } catch (error) {
        res.status(500).send({ error: 'Failed to fetch todos' });
    }
});

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Primary app running on http://localhost:${PORT}`);
});