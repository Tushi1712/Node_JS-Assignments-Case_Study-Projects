const http = require('http');
const url = require('url');
const qs = require('querystring');

const server = http.createServer((req, res) => {
  const parsedUrl = url.parse(req.url, true);
  const path = parsedUrl.pathname;

  if (path === '/form' && req.method === 'GET') {
    res.writeHead(200, {'Content-Type': 'text/html'});
    res.end(`
      <html>
        <body>
          <form action="/submit" method="post">
            <label for="name">Name:</label>
            <input type="text" id="name" name="name">
            <br>
            <label for="email">Email:</label>
            <input type="text" id="email" name="email">
            <br>
            <button type="submit">Submit</button>
          </form>
        </body>
      </html>
    `);
  } else if (path === '/submit' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => {
      body += chunk.toString();
    });
    req.on('end', () => {
      const formData = qs.parse(body);
      res.writeHead(200, {'Content-Type': 'text/html'});
      res.end(`
        <html>
          <body>
            <h1>Form Data</h1>
            <p>Name: ${formData.name}</p>
            <p>Email: ${formData.email}</p>
          </body>
        </html>
      `);
    });
  } else if (path === '/querystring') {
    res.writeHead(200, {'Content-Type': 'text/html'});
    const query = parsedUrl.query;
    res.end(`
      <html>
        <body>
          <h1>Querystring Data</h1>
          <p>${JSON.stringify(query)}</p>
        </body>
      </html>
    `);
  } else {
    res.writeHead(404, {'Content-Type': 'text/html'});
    res.end('<h1>404 Not Found</h1>');
  }
});

server.listen(3000, () => {
  console.log('Server is listening on port 3000');
});
