// handler.js
const eventHandler = () => {
    console.log('User connected');
  };
  
  module.exports = eventHandler;
  