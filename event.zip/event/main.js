// main.js
const EventEmitter = require('events');
const eventHandler = require('./handler');

const emitter = new EventEmitter();

// Register the event handler with the 'connect' event
emitter.on('connect', eventHandler);

// Emit the 'connect' event
emitter.emit('connect');
